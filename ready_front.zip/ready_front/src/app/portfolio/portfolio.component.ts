import { Component, OnInit } from '@angular/core';
import {UserService} from "../services/user.service";
import {Balance, Portfolio} from "../../models";

@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.component.html',
  styleUrls: ['./portfolio.component.css']
})
export class PortfolioComponent implements OnInit {
  portfolio: Portfolio[] = [];
  balance: number = 0;
  investments: String = '0';

  constructor(
    private userService: UserService
  ) { }

  ngOnInit(): void {
    this.getPortfolio();
    this.getBalance();
  }

  getBalance(){
    this.userService.getBalance().subscribe((data) => {
      this.balance = data.balance;
    });
  }

  getPortfolio(){
    this.userService.getPortfolio().subscribe((data) => {
      this.portfolio = data;
      this.calculateInvestments();
    });
  }

  calculateInvestments(){
    let sum = 0;
    for(let curr of this.portfolio){
      sum = sum + (curr.quantity * curr.crypto_id.quote.USD.price);
    }
    this.investments = sum.toFixed(2);
  }
}

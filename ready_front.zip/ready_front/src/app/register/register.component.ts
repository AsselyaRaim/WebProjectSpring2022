import { Component, OnInit } from '@angular/core';
import {User} from "../../models";

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  login: String = '';
  name: String = '';
  surname: String = '';
  email: String = '';
  password: String = '';

  constructor() { }

  ngOnInit(): void {
  }

  Register(){
    let new_user = {
      "name": this.name,
      "surname": this.surname,
      "email": this.email,
      "password": this.password
    };
    console.log(new_user);
  }

}

import { Injectable } from '@angular/core';
import {Balance, Portfolio, User, AuthToken} from "../../models";
import {HttpClient} from "@angular/common/http";
import {Observable, of} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class UserService {

  BASE_URL = "http://127.0.0.1:8000/"

  constructor(
    private http: HttpClient
  ) { }

  getUser(): Observable<User>{
    return this.http.get<User>('/assets/jsons/user.json');
  }

  getBalance(): Observable<Balance>{
    return this.http.get<Balance>('/assets/jsons/balance.json');
  }

  getPortfolio(): Observable<Portfolio[]>{
    return this.http.get<Portfolio[]>('assets/jsons/portfolio.json');
  }

  //added requests
  createUser(): Observable<User>{
    return this.http.post<User>('assets/jsons/portfolio.json', {
      //create user
    });
  }

  login(login: String, password: String): Observable<AuthToken> {
    return this.http.post<AuthToken>(`${this.BASE_URL}api/login/`, {
      "username": login,
      "password": password
    })
  }


}
